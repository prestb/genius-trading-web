"use client";

import { useMemo, useState } from "react";
import {
  Activity, ArrowDownRight, ArrowUpRight, Bell, BrainCircuit, CandlestickChart,
  ChevronDown, CircleHelp, Clock3, LayoutDashboard, LineChart, Search, Settings2,
  ShieldCheck, SlidersHorizontal, Sparkles, Star, TrendingUp, WalletCards
} from "lucide-react";

type Market = "Forex" | "Crypto" | "Stocks" | "Indices";
const marketSymbols: Record<Market, string[]> = {
  Forex: ["EUR/USD", "GBP/USD", "USD/JPY", "EUR/GBP"],
  Crypto: ["BTC/USD", "ETH/USD", "SOL/USD", "XRP/USD"],
  Stocks: ["AAPL", "NVDA", "MSFT", "TSLA"],
  Indices: ["SPX", "NDX", "DJI", "FTSE 100"],
};

const sampleBars = [34, 41, 38, 48, 43, 50, 45, 56, 52, 61, 57, 64, 55, 60, 72, 66, 76, 69, 80, 74, 83, 78, 88, 81, 92, 86, 95, 89, 98, 92, 103, 96, 107, 101, 112, 105, 116, 109, 120, 113, 124, 118, 129, 121, 133, 126, 137, 131];

export default function Home() {
  const [market, setMarket] = useState<Market>("Forex");
  const [symbol, setSymbol] = useState("EUR/USD");
  const [timeframe, setTimeframe] = useState("15m");
  const [activeNav, setActiveNav] = useState("Overview");
  const [search, setSearch] = useState("");
  const [watchlist, setWatchlist] = useState<string[]>(["EUR/USD", "BTC/USD", "AAPL"]);
  const [notice, setNotice] = useState("Demo interface — connect a market-data provider to enable real analysis.");

  const symbols = marketSymbols[market];
  const visibleSymbols = useMemo(
    () => symbols.filter((item) => item.toLowerCase().includes(search.toLowerCase())),
    [symbols, search]
  );

  function changeMarket(next: Market) {
    setMarket(next);
    setSymbol(marketSymbols[next][0]);
  }

  function toggleWatchlist(item: string) {
    setWatchlist((current) => current.includes(item) ? current.filter((x) => x !== item) : [...current, item]);
  }

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Sparkles size={22} strokeWidth={2.4} /></div>
          <div><div className="brand-name">GENIUS</div><div className="brand-subtitle">TRADING INTELLIGENCE</div></div>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav className="nav-list" aria-label="Main navigation">
          {[
            { label: "Overview", icon: LayoutDashboard },
            { label: "Markets", icon: CandlestickChart },
            { label: "AI Signal Lab", icon: BrainCircuit },
            { label: "Signal History", icon: Activity },
            { label: "Watchlist", icon: Star },
          ].map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-item ${activeNav === label ? "active" : ""}`} onClick={() => setActiveNav(label)}>
              <Icon size={17} /><span>{label}</span>{label === "AI Signal Lab" && <span className="nav-dot" />}
            </button>
          ))}
        </nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-card">
          <div className="sidebar-card-icon"><ShieldCheck size={18} /></div>
          <div className="sidebar-card-title">Analysis integrity</div>
          <p>Signals will only use verified market data. No data, no signal.</p>
          <span className="status-pill"><span className="status-dot" /> Guardrails enabled</span>
        </div>
        <button className="nav-item settings-button" onClick={() => setNotice("Settings will be added in a later phase.")}><Settings2 size={17} /><span>Settings</span></button>
        <div className="profile-row">
          <div className="avatar">G</div><div className="profile-copy"><strong>Personal workspace</strong><span>Private account</span></div><ChevronDown size={15} className="muted-icon"/>
        </div>
      </aside>

      <section className="main-panel">
        <header className="topbar">
          <div className="breadcrumb"><span>Workspace</span><span className="crumb-slash">/</span><strong>{activeNav}</strong></div>
          <div className="topbar-actions">
            <div className="connection-status"><span className="status-dot amber" /> Demo mode</div>
            <button className="icon-button" aria-label="Help" onClick={() => setNotice("This starter currently uses illustrative data only.")}><CircleHelp size={18}/></button>
            <button className="icon-button" aria-label="Notifications" onClick={() => setNotice("Notifications will be configured after live data is connected.")}><Bell size={18}/></button>
            <div className="top-avatar">G</div>
          </div>
        </header>

        <div className="content">
          <section className="welcome-row">
            <div>
              <div className="eyebrow"><span className="eyebrow-line" /> PERSONAL MARKET TERMINAL</div>
              <h1>Market overview<span className="title-period">.</span></h1>
              <p className="subtitle">Your market, your signals, your decisions.</p>
            </div>
            <button className="date-button" onClick={() => setNotice("Live market timestamps will appear when the data provider is connected.")}><Clock3 size={15}/> <span>Market data not connected</span></button>
          </section>

          <div className="demo-alert"><div className="alert-icon"><Activity size={16}/></div><div><strong>Starter preview</strong><span>{notice}</span></div><button onClick={() => setNotice("Demo interface — connect a market-data provider to enable real analysis.")} aria-label="Reset notice">×</button></div>

          <section className="metric-grid">
            <div className="metric-card"><div className="metric-top"><span>Tracked markets</span><span className="metric-icon"><CandlestickChart size={16}/></span></div><div className="metric-value">12 <small>in preview</small></div><div className="metric-foot">Across 4 asset categories</div></div>
            <div className="metric-card"><div className="metric-top"><span>Signals today</span><span className="metric-icon orange"><BrainCircuit size={16}/></span></div><div className="metric-value">—</div><div className="metric-foot">Awaiting verified data</div></div>
            <div className="metric-card"><div className="metric-top"><span>Data connection</span><span className="metric-icon"><Activity size={16}/></span></div><div className="metric-value metric-status">Not connected</div><div className="metric-foot"><span className="status-dot amber" /> Demo mode active</div></div>
            <div className="metric-card"><div className="metric-top"><span>AI analysis</span><span className="metric-icon purple"><Sparkles size={16}/></span></div><div className="metric-value metric-status">Standby</div><div className="metric-foot">No signals fabricated</div></div>
          </section>

          <div className="section-heading"><div><h2>Market explorer</h2><p>Select a market and instrument to inspect.</p></div><button className="secondary-button" onClick={() => setNotice("Filters will be connected to real instruments in Phase 2.")}><SlidersHorizontal size={15}/> Filters</button></div>

          <section className="market-layout">
            <div className="panel chart-panel">
              <div className="chart-header">
                <div className="symbol-heading"><div className="coin-icon">{market === "Crypto" ? "₿" : market === "Stocks" ? "S" : market === "Indices" ? "▥" : "€"}</div><div><div className="symbol-name">{symbol}<ChevronDown size={14}/></div><div className="symbol-caption">{market} <span className="bullet">·</span> <span className="muted">Illustrative preview</span></div></div></div>
                <div className="timeframe-list">{["1m", "5m", "15m", "1h", "4h", "1D"].map((tf) => <button key={tf} className={timeframe === tf ? "selected" : ""} onClick={() => setTimeframe(tf)}>{tf}</button>)}</div>
              </div>
              <div className="chart-price-row"><div><span className="price-label">Illustrative price</span><div className="price-value">— <span className="price-change">Live data unavailable</span></div></div><button className="chart-action" onClick={() => setNotice("Connect Twelve Data or another licensed provider to render real candles.")}><LineChart size={15}/> Connect data</button></div>
              <div className="chart-wrap">
                <div className="chart-y-labels"><span>High</span><span>—</span><span>—</span><span>—</span><span>Low</span></div>
                <svg className="candle-chart" viewBox="0 0 720 270" preserveAspectRatio="none" role="img" aria-label="Illustrative candlestick chart placeholder">
                  {[30, 80, 130, 180, 230].map((y) => <line key={y} x1="0" y1={y} x2="720" y2={y} className="chart-gridline" />)}
                  {sampleBars.map((y, i) => {
                    const x = 10 + i * 14.7; const rising = i % 5 !== 1 && i % 7 !== 3;
                    const bodyTop = Math.max(12, 240 - y * 1.6); const bodyHeight = 8 + (i % 5) * 3;
                    return <g key={i} className={rising ? "candle-up" : "candle-down"}><line x1={x + 4} y1={bodyTop - 9 - (i % 4) * 2} x2={x + 4} y2={bodyTop + bodyHeight + 10} stroke="currentColor" strokeWidth="1.2"/><rect x={x} y={bodyTop} width="8" height={bodyHeight} rx="1" fill="currentColor"/></g>;
                  })}
                  <path d="M 0 205 C 80 180, 110 190, 170 155 S 250 170, 315 130 S 410 155, 470 100 S 560 112, 620 70 S 680 85, 720 38" fill="none" stroke="#e99058" strokeWidth="1.7" strokeDasharray="4 5" opacity=".8"/>
                </svg>
                <div className="chart-watermark"><CandlestickChart size={18}/> Chart preview only</div>
              </div>
              <div className="chart-legend"><span><i className="legend-dot green"/> Bullish candle</span><span><i className="legend-dot red"/> Bearish candle</span><span><i className="legend-line"/> Illustrative trend</span></div>
            </div>

            <aside className="panel signal-panel">
              <div className="panel-title-row"><div><div className="panel-kicker"><Sparkles size={14}/> GENIUS AI</div><h3>Signal analysis</h3></div><span className="soon-pill">NOT CONNECTED</span></div>
              <div className="signal-empty"><div className="brain-orb"><BrainCircuit size={26}/></div><h4>Ready when data is</h4><p>Connect a real market-data source to begin evidence-based analysis.</p><button className="primary-button" onClick={() => setNotice("Next: configure your market-data API key in .env.local and implement the server-side data adapter.")}><Sparkles size={15}/> Prepare data connection</button></div>
              <div className="analysis-checks"><div className="checks-heading">ANALYSIS CHECKLIST <span>0/6</span></div>{["Trend direction", "EMA 50 / 200", "RSI momentum", "Support & resistance", "Volatility (ATR)", "Data freshness"].map((item) => <div className="check-row" key={item}><span className="check-empty"/><span>{item}</span><span className="check-pending">Pending</span></div>)}</div>
              <div className="signal-disclaimer"><ShieldCheck size={15}/><span>Genius will not issue a live signal until the required market data has been validated.</span></div>
            </aside>
          </section>

          <div className="section-heading watch-heading"><div><h2>Watchlist</h2><p>Quick access to your preferred instruments.</p></div><div className="search-box"><Search size={15}/><input aria-label="Search instruments" placeholder="Search instruments" value={search} onChange={(e) => setSearch(e.target.value)}/></div></div>
          <section className="panel watchlist-panel">
            <div className="market-tabs">{(Object.keys(marketSymbols) as Market[]).map((item) => <button key={item} className={market === item ? "tab-active" : ""} onClick={() => changeMarket(item)}>{item}</button>)}</div>
            <div className="watch-table">
              <div className="watch-table-head"><span>INSTRUMENT</span><span>ASSET CLASS</span><span>PRICE</span><span>CHANGE</span><span>WATCHLIST</span></div>
              {visibleSymbols.map((item, i) => <div className="watch-row" key={item}><div className="watch-instrument"><div className={`mini-symbol color-${i % 4}`}>{item.slice(0, 1)}</div><strong>{item}</strong></div><span className="asset-type">{market}</span><span className="no-data">—</span><span className="no-data">Unavailable</span><button className={`star-button ${watchlist.includes(item) ? "starred" : ""}`} aria-label={`${watchlist.includes(item) ? "Remove" : "Add"} ${item} ${watchlist.includes(item) ? "from" : "to"} watchlist`} onClick={() => toggleWatchlist(item)}><Star size={16} fill={watchlist.includes(item) ? "currentColor" : "none"}/></button></div>)}
              {visibleSymbols.length === 0 && <div className="empty-search">No instruments match “{search}”.</div>}
            </div>
            <div className="table-footer"><span>{visibleSymbols.length} instruments in this preview</span><span>Prices intentionally omitted until connected to live data</span></div>
          </section>
          <footer className="page-footer"><span>GENIUS <span className="footer-sep">/</span> PERSONAL TRADING WORKSPACE</span><span><span className="status-dot amber"/> Demo environment · Not financial advice</span></footer>
        </div>
      </section>
    </main>
  );
}
